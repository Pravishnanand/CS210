#include <iostream>
#include <fstream>
#include <map>
#include <limits>
using namespace std;

class GroceryTracker {
private:
    map<string, int> groceryData; // Private member to store grocery data

public:
    // Constructor to read data from the input file and initialize groceryData
    GroceryTracker() {
        readDataFromFile();
    }

    // Function to read data from the input file and store it in groceryData
    void readDataFromFile() {
        ifstream inputFile("CS210_Project_Three_Input_File.txt");
        if (!inputFile) {
            cerr << "Error opening the input file." << endl;
            exit(1);
        }

        string item;
        while (inputFile >> item) {
            groceryData[item]++;
        }

        inputFile.close();
    }

    // Function to find the frequency of a specific item
    void findFrequency(const string& itemToFind) {
        if (groceryData.find(itemToFind) != groceryData.end()) {
            cout << "Frequency of " << itemToFind << ": " << groceryData[itemToFind] << endl;
        }
        else {
            cout << "Item not found." << endl;
        }
    }

    // Function to display the overall frequency of all items
    void displayOverallFrequency() {
        for (const auto& pair : groceryData) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    // Function to display a histogram of item frequencies
    void displayHistogram() {
        for (const auto& pair : groceryData) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; i++) {
                cout << "*";
            }
            cout << endl;
        }
    }

    // Function to create a data backup file
    void createBackupFile() {
        ofstream outputFile("frequency.dat");
        if (!outputFile) {
            cerr << "Error creating the output file." << endl;
            exit(1);
        }

        for (const auto& pair : groceryData) {
            outputFile << pair.first << " " << pair.second << endl;
        }

        outputFile.close();
    }
};

int main() {
    GroceryTracker tracker; // Create an instance of the GroceryTracker class

    int choice;
    do {
        cout << "Menu Options:" << endl;
        cout << "1. Find the frequency of a specific item" << endl;
        cout << "2. Display overall frequency of all items" << endl;
        cout << "3. Display a histogram of item frequencies" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";

        while (!(cin >> choice)) {
            cout << "Invalid input. Please enter a valid integer: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        switch (choice) {
        case 1: {
            string itemToFind;
            cout << "Enter the item you wish to find: ";
            cin >> itemToFind;
            tracker.findFrequency(itemToFind);
            break;
        }
        case 2: {
            tracker.displayOverallFrequency();
            break;
        }
        case 3: {
            tracker.displayHistogram();
            break;
        }
        case 4:
            cout << "Exiting the program." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 4);

    tracker.createBackupFile(); // Create a data backup file using the GroceryTracker instance

    return 0;
}